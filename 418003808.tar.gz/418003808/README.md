# Practica1
Funciones varias en Haskell


Edgar Quiroz Castañeda 418003808